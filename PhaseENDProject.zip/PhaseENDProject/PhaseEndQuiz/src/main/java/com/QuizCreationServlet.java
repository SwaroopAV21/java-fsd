package com;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class QuizCreationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String question = request.getParameter("question");
        String choice = request.getParameter("choice");
        String correct = request.getParameter("correct");

        try {
            // Establish database connection
        	Class.forName("com.mysql.jdbc.Driver");
	        Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/phasetwo", "root", "Qwer123!@#");


            // Prepare the SQL statement
            String sql = "INSERT INTO Questions (question, choice,correcta) VALUES (?, ?,?)";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, question);
            statement.setString(2, choice);
            statement.setString(3, correct);

            // Execute the SQL statement
            int rowsInserted = statement.executeUpdate();

            if (rowsInserted > 0) {
                System.out.println("Question and choice added successfully.");
            } else {
                System.out.println("Failed to add question and choice.");
            }

            // Clean up resources
            statement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        catch(ClassNotFoundException e) {
        	e.printStackTrace();
        }
    }
}
