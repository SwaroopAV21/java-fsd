package psone;
class inner1{
	String msg="Welcome";
	class inner{
		void display() {
			System.out.println(msg+"");
		}
	}
}
class inner2{
	String msg="Come";
	void display() {
		class innerr{
			void msg() {
				System.out.println("Innerclasses");
			}
		}
		innerr in=new innerr();
		in.msg();
	}
}
abstract class ainner{
      public abstract void display();
}
public class Pseven {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		inner1 in1=new inner1();
		inner1.inner  in=in1.new inner();
		in.display();
		
		inner2 in2=new inner2();
		in2.display();
		
		ainner ai=new ainner() {
		 public void display(){
			System.out.println("ainner");
		}
		};
		ai.display();
		

	}

}
