package psone;
 class  method {
	static int add(int a, int b) {
		int c =a+b;
		return c;
	}
}
 class overloading {
	 static int add(int a, int b) {
		 int c=a+b	;	
		 return c;
	 }
	 static int add(int a) {
		 int b=a+a;
		 return b;
	 }
 }
public class Pstwo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		method m= new method();
		overloading ov= new overloading();
		int z=m.add(10,3);
		System.out.println("This result is from method :"+z);
		System.out.println("This is from overloading:" +ov.add(5));
		System.out.println("This is from overloading:" +ov.add(5,4));
	}
}

