package psone;

public class Psone {

	public static void main(String[] args) {
		char a='A';int b=a;  float c=a; long e=a; double d=a;byte f=10 ;
		System.out.println("Value of char int float double long "+a +" " +b+ " " +c+" " +d+" " +e+" -"+f);
		System.out.println("\n");
		double x=45.5;int y=(int)x;
		System.out.println("Value  is " +x + "-After changing the value: "+y);
	}

}
