package psone;

public class Psnine {
	public static void main(String[] args) {
		int a[]= {10,20,30,40,50};
		int b[][]= { {10,20,30}, {40,50,60}};
		
		for(int i=0;i<a.length;i++) {
			System.out.println("Array elments:"+a[i]);
		}
		System.out.println("Lenght of row 1:"+b[0].length);
	}

}
