package psone;
import java.util.*;
public class Pssix {
	public static void main(String[] args) {
		HashMap<Integer,String> hm= new  HashMap<Integer,String>();
		hm.put(8, "ALex");
		hm.put(2, "NINA");
		
		System.out.println("HASHmap:\n");
		for(Map.Entry m:hm.entrySet()) {
			System.out.println(m.getKey() +""+m.getValue());		
			}
		
		Hashtable<Integer,String> ht =new Hashtable<Integer,String>();
		ht.put(5,"Jhon");
		ht.put(3, "Braxe");
		System.out.println("HASHtable:\n");
		for(Map.Entry n:ht.entrySet()) {
			System.out.println(n.getKey() +""+n.getValue());		
			}
		
		TreeMap<Integer,String> tm=new TreeMap<Integer,String>();
		tm.put(7, "Annie");
		System.out.println("TreeMap:\n");
		for(Map.Entry l:tm.entrySet()) {
			System.out.println(l.getKey()+" "+l.getValue());
		}
	}
}
