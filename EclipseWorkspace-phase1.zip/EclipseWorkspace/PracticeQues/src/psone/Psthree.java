package psone;
class construct{
	int i;String name;
	
	void display() {
		System.out.println("Id"+i+"Name"+name);
	}
}
class preconstructor{
	int i; String name;
	preconstructor(int a, String n){
		i=a;
		name=n;
	}
	void display() {
		System.out.println("ID"+i+"NAME"+name);
	}
}

public class Psthree {
	public static void main(String[] args) {
		construct c= new construct();
		
		preconstructor pc =new preconstructor(1,"Jhon");
		
		c.display();
		pc.display();
				
	}

}
