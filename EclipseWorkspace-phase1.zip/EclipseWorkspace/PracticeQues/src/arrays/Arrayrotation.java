package arrays;


class rotate{
	public void arotate(int[]nums,int k) {
		if(k>nums.length) {
			k=k%nums.length;
		}
		int [] r = new int[nums.length];
		for(int i=0;i<k;i++) {
			r[i]=nums[nums.length-k+i];
		}
		int j=0;
		for(int i=k;i<nums.length;i++) {
			r[i]=nums[j];
			j++;
		}
		System.arraycopy(r,0,nums,0,nums.length);
	}
}
public class Arrayrotation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		rotate r = new rotate();
		int[] ar= {10,20,30,40,50,60};
		r.arotate(ar,2 );
		for(int i=0;i<ar.length;i++) {
			System.out.println(ar[i]+" ");
		}

	}

}
