package arrays;

public class Matrix {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int r1=2,c1=3;
		int r2=3,c2=2;
		int[][] fm= {{3,-2,5},{3,0,4}};
		int[][] sm= {{2,3},{-9,0},{0,4}};
		int[][] prod=mulmatrix(fm,sm,r1,c1,c2);
		display(prod);

	}

	public static void display(int[][] prod) {
		// TODO Auto-generated method stub
		System.out.println("Product is:");
		for(int[] row:prod) {
			for(int col:row) {
				System.out.println(col+" ");
			}
			System.out.println("\n");
		}
		
	}

	public static int[][] mulmatrix(int[][] fm, int[][] sm, int r1, int c1, int c2) {
		// TODO Auto-generated method stub
		int [][] prod= new int[r1][c2];
		for(int i=0;i<r1;i++) {
			for(int j=0;j<c2;j++) {
				for(int k=0;k<c1;k++) {
					prod[i][j]+=fm[i][k]*sm[k][j];
				}
			}
		}
		return prod;
	}

}
