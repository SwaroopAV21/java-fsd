package arrays;

public class Rangeq {
	
	static int k=16;
	static int n=100000;
	static long t[][]=new long[n][k+1];
	static void sparsetable(int a[],int n) {
		for(int i=0;i<n;i++) t[i][0]=a[i];
		for(int j=1;j<=k;j++) {
			for(int i=0;i<=n-(1<<j);i++) {
				t[i][j]=t[i][j-1]+t[i+(1<<(j-1))][j-1];	
			}
			}
		}
	static long query(int L,int R) {
		long ans=0;
		for(int j=k;j>=0;j--) {
			if(L+(1<<j)-1<=R) {
				ans=ans+t[L][j];
				L+=1<<j;
			}
		}
		return ans;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]= {3,7,2,5,8,9};
		int n=a.length;
		sparsetable(a,n);
		System.out.println(query(0,5));
		System.out.println(query(3,5));
		System.out.println(query(2,4));
		

	}

}
