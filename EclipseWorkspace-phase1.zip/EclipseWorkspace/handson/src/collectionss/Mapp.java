package collectionss;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;
public class Mapp {
	

	public static void main(String[] args) {
		//map demo
		Map<String,Integer> mp = new HashMap<String, Integer>();
		mp.put("Delhi",45);
		mp.put("Bengaluru",22);
		mp.put("Goa",25);
		 
		System.out.println("Bengaluru has:" +mp.get("Bengaluru"));
		
		for(Map.Entry m:mp.entrySet()) {
			System.out.println(m.getValue()+"-"+mp.entrySet());
		}
		
		//tree map searching is fast in tree
		//adding and deleting is slow in tree but others are fast like hashmap
		Map<String,Integer> tm=  new TreeMap<String,Integer>();
		tm.put("Delhi", 12);
		
		for(Map.Entry t:tm.entrySet()) {
			System.out.println(t.getValue()+" "+tm.entrySet());
		}
		
		
	}
	

}
