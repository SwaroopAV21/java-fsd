package collectionss;

public class Mainprogramforinnerclass {

	public static void main(String[] args) {
		// how to call innerclasses is given
		Innerclass in=new Innerclass();
		//Innerclass.class cin=in.new class1();
		Innerclass.class1 cin = new Innerclass().new class1();
		cin.display();
		cin.displayp();
		
//		Innerclass2 in2 = new Innerclass2();
//		in2.display();
		
		//anonymous class
		Innerclass2 in2 = new Innerclass2() {
			public void display3() {
				
			}
		};
		in2.displya4();
	
	}
}
