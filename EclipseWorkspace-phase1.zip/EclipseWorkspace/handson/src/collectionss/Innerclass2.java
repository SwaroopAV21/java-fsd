package collectionss;

//public class Innerclass2 {
// private String msg="String";
//	void display() {
//		//another way of using inner class 
//		class inner {
//			void msg() {
//				System.out.println(msg);
//			}
//		}
//		inner in=new inner();
//		in.msg();
//	}
//}
//anonymous class----****----
	abstract class Innerclass2 {
		abstract public void display3();
		
		public void displya4() {
			System.out.println("INside display 4:");
		}
		
}
