package collectionss;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.util.Vector;
import java.util.LinkedList;


public class Collectionslive {

	public static void main(String[] args) {
		// LISTDEMO
		//why list instead of array list its because u can change list anytime on the right side
		List<String> citylist=new ArrayList<String>();
		citylist.add("Bengaluru");
		citylist.add("Delhi");
		citylist.add("mumbai");
		
		
		//Navigate using for each
		for(String a:citylist) {
			System.out.println("City List:"+citylist+" This is the string in a:"+a);
		}
		
		//method 2 using itertor
		Iterator<String> it=citylist.iterator();	
		while(it.hasNext()) {
			System.out.println(it.next());
		}
		
		//vector 
		Vector<String> citylistvector = new Vector<String>();
		citylistvector.addElement("Bengaluru");
		citylistvector.addElement("Delhi");
		citylistvector.addElement("mumbai");
		
		for(String a:citylistvector) {
			System.out.println("City List:"+citylist+" This is the string in a:"+a);
			System.out.println("\n");
		}
		
		
		//using inked list for fruits
		System.out.println("Linked list");
		List<String> fruits = new LinkedList<String>();
		
//		System.out.println("Enter the fruits");
//		Scanner sc=new Scanner(System.in);
//		String fru=sc.next();
		fruits.add("Apple");
		fruits.add("Mango");
		fruits.add("Bannana");
//		fruits.add(fru);
		
		for(String f:fruits) {
			System.out.println(f+"-"+fruits);
		}
		
		
		//hashset
		HashSet<Integer> hashset = new HashSet<Integer>();
		hashset.add(15);
		hashset.add(12);
		
		for(int ab: hashset) {
			System.out.println(ab);
		}
		
	
	}

}
