package collectionss;

public class Innerclass {
	private int price=85;
	
	class class1{
		int age;
		public void display() {
			System.out.println("Age innerclass1:");
		}
		//inner class having access to private price
		public void displayp() {
			System.out.println("Price innerclass1:"+price);
		}
	}

}
