package handson;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.Arrays;
import java.util.List;

public class Filehandlingg {

	public static void main(String[] args) throws IOException {
		createFileUsingFileClass();
		createFileUsingSystemOut();
		createFile_Nio();

	}
	
	private static void createFile_Nio() throws IOException{
		// TODO Auto-generated method stub
		String test="test data";
		Files.write(Paths.get("c://temp//testFile1.txt"),test.getBytes());
		List<String> l= Arrays.asList("1st list");
		Files.write(Paths.get("file6.txt"),l,StandardCharsets.UTF_8,
                StandardOpenOption.CREATE,
                StandardOpenOption.APPEND);	
	}

	private static void createFileUsingSystemOut() throws IOException {
		// TODO Auto-generated method stub
		String TestData="testdata";
		FileOutputStream op=new FileOutputStream("c://temp//testFile1.txt");
		op.write(TestData.getBytes());
		op.close();
	}

	private static  void createFileUsingFileClass() throws IOException{
		File file= new File("c://temp//testFile1.txt");
		
		if(file.createNewFile()) {
			System.out.println("File created");
		}else System.out.println("ALready exists");
		FileWriter w= new FileWriter(file);
		w.write("Hello");
		w.close();
	}
	
	

}
