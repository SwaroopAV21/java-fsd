package handson;

public class Sleepnwait {
	public static Object o=new Object();
	public static void main(String[] args) throws InterruptedException {
		Thread.sleep(100);
		System.out.println(Thread.currentThread().getName());
		synchronized(o){
			o.wait(1000);
			System.out.println(o);
		}
	}
	

}
