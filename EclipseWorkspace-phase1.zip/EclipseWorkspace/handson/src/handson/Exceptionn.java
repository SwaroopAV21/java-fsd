package handson;

class Myexception extends Exception{
	String str1;
	Myexception(String str2){
		str1=str2;
	}
	public String toString() {
		return(str1);
	}
}

public class Exceptionn {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try
		{
			System.out.println("Starting:");
			throw new Myexception("New New");
		}
		catch(Myexception e) {
			System.out.println(e);
		}

	}

}