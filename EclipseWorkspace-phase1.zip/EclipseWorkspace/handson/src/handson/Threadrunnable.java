package handson;

public class Threadrunnable implements Runnable {

	public static int c=0;
	public Threadrunnable() {
		
	}

	@Override
	public void run() {
		
		while(Threadrunnable.c<=10) {
			try {
			System.out.println("ThreadNumber:"+(++Threadrunnable.c));
			Thread.sleep(100);
		}
			catch(InterruptedException e){
				System.out.println("expl"+e.getLocalizedMessage());
			}
		}
		
	}
	public static void main(String[] args) {
		Threadrunnable t=new Threadrunnable();
		Thread  tt= new Thread(t);
		
		tt.start();
		while(Threadrunnable.c<=10) {
			try {
			System.out.println("ThreadNumber:"+(++Threadrunnable.c));
			Thread.sleep(100);
		}
			catch(InterruptedException e){
				System.out.println("Main"+e.getLocalizedMessage());
			}
		}
	}
}
