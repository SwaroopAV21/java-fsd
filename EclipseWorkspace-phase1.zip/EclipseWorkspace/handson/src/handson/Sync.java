package handson;


class sender{
	public void send(String msg) {
		System.out.println("Sending\n");
		try {
			Thread.sleep(1000);
		}
		catch(Exception e){
			System.out.println("interrupted:");		
		}
		System.out.println("Sent:"+msg+"\n");
	}
}
class Mythread extends Thread{
	private String msg;
	private sender s;
	private Thread t;
	Mythread(String m, sender str){
		msg=m;
		s=str;
	}
	public void run() {
		synchronized(s) {
			s.send(msg);
		}
	}
}

public class Sync {

	public static void main(String[] args) {
		sender st=new sender();
		Mythread mt=new Mythread("HI",st);
		Mythread mt1=new Mythread("bye",st);
		mt.start();
		mt1.start();
		try {
			mt.join();
			mt1.join();
		}
		catch(Exception e) {
			System.out.println("interrupted:");
		}

	}

}
