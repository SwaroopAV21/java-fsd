package handson;

public class Demoerror {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try{
			int arr[]={10,20,30,40};
			//String str=null;
			//int num =20/0;
			//System.out.println(str.length());
			System.out.println(arr[10]);
		}
		catch(ArithmeticException e) {
			System.out.println("Erro"+e);
		}
		catch(ArrayIndexOutOfBoundsException e) {
			System.out.println("Erro:"+e);
		}
		catch(NullPointerException e) {
			System.out.println("Error:"+e);
		}
		finally {
			System.out.println("this always block exceute");
		}
		System.out.println("out of all exceptions");

	}

}
