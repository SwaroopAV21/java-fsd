package arrays;

public class Arrays {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//declare an array 
		int[] b;
		b=new int[5];//defining an array

		//adding elements to array
		b[0]=1;b[1]=2;b[2]=3;b[3]=4;b[4]=5;		
		
		for(int i=0;i<b.length;i++) {System.out.println(b[i]);}
		for(int i:b) {System.out.println(i);}
		
		//can be declare by this 
		int[] c=new int[5];
		
		//2nd approach
		int a[]= {1,2,3,4,5};
		for(int i :a) {	System.out.println("-"+i);	}
		
		//2D array
		int[][] a2= {{10,20,30},{40,50,60}};
		for(int i=0;i<a2.length;i++) {
			for(int j=0;j<a2[i].length;j++) {System.out.println(a2[i][j]);}}

	}
	}

