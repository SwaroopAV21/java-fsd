package arrays;
import java.util.regex.*;
import java.util.Scanner;

public class Patternprojects {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//using regular expression
		String check="Regular Expression";
		
		//string contains lower expressions + indicates any number of times
		String pattern = "[a-z]+";//[A-Z]+ for upper case
		
		Pattern p= Pattern.compile(pattern);
		Matcher m=p.matcher(check);
		
//		System.out.println("Matcher found or not:"+m.find());
		
		while(m.find()) {
			int start = m.start();
			int end = m.end();
			System.out.println(check.substring(start ,end));
			
			}
		
		//to find the number
		
		String ph="this is the mobile number 454545455";
		Pattern pp = Pattern.compile("[0-9]{10}");
		Matcher mm=pp.matcher(ph);
		while(mm.find()) {
			int start = m.start();int end= m.end();
			System.out.println(ph.substring(start,end));
		}
		
		//email validation
		
		Scanner sc=new Scanner(System.in);
		String sss=sc.next();
		
		String regex ="^(.+)@(.+)$";
		
		Pattern pt= Pattern.compile(regex);
		Matcher mc= pt.matcher(sss);
		
		System.out.println(m.find());
		

	}

}
