package multithreading;

public class Syncc {
	public static void main(String[] args) {
		System.out.println("Sync demo:");
		
		Postman cp= new Postman();
		
		Postman2 p1= new Postman2(cp,"HI");
		Postman2 p2= new Postman2(cp,"bye");
		
		p1.start();
		p2.start();
		//so here we cane see that first hi and bye was done and then the sent message poped,
		//so we use synced in the run method in postman2
	}

}
