package multithreading;

public class Postman2 extends Thread {

	//instead of postman2 we can name as person
	//here we are using the postman class,so that we can create a thread
	
	Postman ps;
	String msg;
	
	public Postman2(Postman ps,String msg) {
		super();
		this.ps=ps;
		this.msg=msg;
	}
	public void run() {
		synchronized(ps) {
		ps.send(msg);
		}
	}
//we are creating  a synced class in one more class
}
	

