package multithreading;

public class Postman {
	
	
	String msg;
	
	public void send(String msg) {
		System.out.println("Sending::"+msg);
		//after send let the post man sleep 
		try {
			//thinking that the post man is packing and its aboout to go .
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("sent:-:");
	}
	//we will create a new class to use this postman class.
}
