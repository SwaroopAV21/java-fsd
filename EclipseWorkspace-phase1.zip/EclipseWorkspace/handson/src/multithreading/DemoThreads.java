package multithreading;

public class DemoThreads extends Thread {
	
	
	//we can create lock like this
	 private static Object LOCK = new Object();

	public void run() {
		for(int i=0;i<5;i++) {
			//with this we can see how and which threads can be executed.
			System.out.println(Thread.currentThread().getName()+ "::"+i);
		}
	}	
public static void main(String[] args) {
	//we can create a new class of main method too 
	//i am creating in this class so that we can see the thread methods.
	
	DemoThreads mt=new DemoThreads();
	DemoThreads mt2=new DemoThreads();
	
	
	//using runnable i have created a new class
	Threadusingrunnable mr= new Threadusingrunnable();
	Thread mr1= new Thread(mr);
	//runnable thread,its another type
	mr1.start();
	
	mt.start();
	mt2.start();
	
	
	
	//sleep and wait code with be from this line ,
	//making the main thread sleep for 1 sec that is 1000ms;
	try {
		Thread.sleep(1000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	//after this we can see that the main thread will be exceuted at the last of all the threads
	//more the time more the position of execution .and sleep should always be in try catch block.
	
	
	//using syncronized
	System.out.println("Wait demo:");
	synchronized(LOCK) {
		System.out.println("Lock waiting goin to sleep");
		try {
			LOCK.wait(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//using this too we can put the main method to a wait of any other method by just declaring in that method.
		//we can see how the main  method will be done after 5 secs. but here i hv already set a sleep of 1 secs so it will be done in 6 secs total.
		
	}
	
	
	
	
	
	
	//this  print statement will be executed before the thread call, because it first gives chance to main 
	//it all depends on the cpu to priotize the threads , may be in some run this print will be in the last.
	System.out.println("ENd of thread");
}
}
