package multithreading;

public class Threadusingrunnable implements Runnable {
public void run() {
	for(int i=0;i<5;i++)
	System.out.println(Thread.currentThread().getName() + " -: " + i);
}
}
//this thread will be called in demo threads so we can see the difference between the thread classes.