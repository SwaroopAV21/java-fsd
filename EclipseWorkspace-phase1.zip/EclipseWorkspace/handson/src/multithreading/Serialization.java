package multithreading;

public class Serialization {

	
	//once we use somename.ser then it will automatically create a object.
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
