package oopss;



//only one class can be public in one java file public file should match the java file name
//encapsulation allows us to hide the data,like making some data private which cannot be visible. provide getter and setter to just to be able to display the private contents, but cannot modify
//inheritance in it we use superspecilty or super
//abstraction means modeling the real world entity into class, putting some data and some operation in a java classes. its different from abstract key word.


//association is a concept in oops too,in it we can create a object of another class in a class.
//syntax
//class Apple{ int price ; address add= new address();}  //this is another class class address{ door,window,pincode;}
//can be of 2 types , aggregations , compostion 
//when ever we call a object it will call tostring() method.
public class Classdemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
//
//package com.simpli;
//
//public class Dog {
//	String name;
//	String breed;
//	int age;
//	String color;
//
//	public Dog(String name, String breed, int age, String color) {
//		this.name = name;
//		this.breed = breed;
//		this.age = age;
//		this.color = color;
//	}
//
//	public String getName() {
//		return name;
//	}
//
//	public String getBreed() {
//		return breed;
//	}
//
//	private int getAge() { //we can access it by encapsulation . obj.getAge(); using getter.
//		return age;
//	}
//
//	public String getColor() {
//		return color;
//	}
//
//	@Override
//	public String toString() {
//		return ("Hi my name is " + this.getName() + ".\nMy breed,age and color are " + this.getBreed() + ", "
//				+ this.getAge() + ", and" + this.getColor() + ".");
//	}
//	
//}
