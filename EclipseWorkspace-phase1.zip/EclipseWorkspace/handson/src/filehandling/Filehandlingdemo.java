package filehandling;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.io.FileReader;
import java.io.FileOutputStream;
public class Filehandlingdemo {

	public static void main(String[] args) throws Exception {
		//create a file
		File f= new File("a1000.txt");
		
		boolean created =f.createNewFile();
		
		if(created) System.out.println("Sucess");
		else System.out.println("Failed");
		
		//write to a  file
		
		FileWriter w= new FileWriter(f);
		w.write("Test data-a");
		w.close();
		
		//using fileoutputstream to create
		String e="FileOutputstream";
		FileOutputStream fo= new FileOutputStream("a2000.txt");
		fo.write(e.getBytes());
		fo.close();
		
//		using NIO(input output)
		
//		String data2="NIO";
//		File.write(Paths.get("a3000.txt"),data2.getBytes());
//		List<String>lines = Arrays.asList("1st line","2nd line");
		
		//read a file
		FileReader r= new FileReader(f);
		System.out.println(r.read());
		r.close();
		
		//date 15th may
		//file updation and deletion
		
//		String path="a1000.txt";
//		modifyFile(path,"as","821");
	}

//	 static void modifyFile(String path, String string, String string2) throws Exception{
//		// TODO Auto-generated method stub
//		 File fil=new File(path);
//		 
//		 String currentcontent="";
//		 
//		 BufferedReader reader= null;
//		 FileWriter writer= null;
//		 
//		 reader = new BufferedReader(new FileReader(fil));
//		 String line = reader.readLine();
//		 
//		 while(line!=null) {
//			 currentcontent = currentcontent +line +System.lineSeparator();
//			 line = reader.readLine();		 
//			}
//		 String newcontent = currentcontent.replaceAll(oldString, newString);
//		 
//		 writer = new FileWriter(fil);
//		 writer.write(newcontent);
//		 
//		 reader.close();
//		 writer.close();
//		
//	}
	
}
