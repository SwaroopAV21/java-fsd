package filehandling;

public class Trycatchwiththrows {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
//		//Exception demo
//		try {
//		int[] ar=new int[3];
//		ar[7]=45;
//		System.out.println("ff");
//		}
//		catch(ArrayIndexOutOfBoundsException e) {
//			System.out.println("aa-"+e.getMessage()+" "+e);
//		}

//		---***---
		//throw 
		
//		int a=45,b=0,rs;
//		if(b==0) {
//			//any exception can be throwed
//			throw (new ArithmeticException("cannot divide by zero"));			
//		}
//		else {
//			rs=a/b;
//			System.out.println("good u can go ahead:"+rs);
//		}
				class2 c2= new class2();
				
				try {
				c2.divide();}
				catch(Exception e) {
					System.out.println("ff");
				}
	}
}
	//throws
	//we use throws because we are aware of this error in this method.
	//if we dont want to use try catch block in this class2 we can use throws or we dont know which error it give or there are so many line then we use throws
	// we can use try catch in the place where we call this class2 function in line 32
class class2{
		void divide() throws Exception {
			int a=45,b=0,rs;
			
			rs=a/b;
			System.out.println("result:"+rs);
		}
	}


