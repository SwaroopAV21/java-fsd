package filehandling;

public class CustomException {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//finally demo
		//finaaly with gets exceuted always .
		try {
		int[] ar=new int[3];
		ar[7]=45;
		System.out.println("ff");
		}
		catch(ArrayIndexOutOfBoundsException e) {
			System.out.println("aa-"+e.getMessage()+" "+e);
		}
		finally {
			System.out.println("---");
		}

	}
}
//custom exception
//	public class CustomException extends Exception {
//		String msg;
//		public CustomException(String str) {
//			this.msg = str;
//			
//		}
//		
//		public String getMessage() {
//			return this.msg;
//}
//}	