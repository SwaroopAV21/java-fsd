package stringss;

public class Stringshandson {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//string buffer does not create any space in string iteral 
		//String buffer is mutable , stored in heap 
		//we can manipulate the data with string buffer 
		
		String s1 = new String("Data");
		System.out.println(s1.length());
		
		//get a substring
		String sub = new String("Welcome");
		System.out.println(sub.substring(5));
		System.out.println(sub.indexOf(3));
		
		//string equality
		//in s1==s2 compares the memory locations of the variables
		//equals compares the the strings
		
		String s2= "Data";
		if(s1.equals(s2)|| s1==s2) {System.out.println("Same");}
		else System.out.println(" Not Same");
		
		//compare
		String s3="abc";
		String s4="abv";
		System.out.println(s3.compareTo(s4));
		//to chech if a string is empty or not , usefull for loops
		System.out.println(s3.isEmpty());
		System.out.println(s3.isBlank());
		//replace
		System.out.println(s3.replace('a','g'));
		System.out.println(s3.toUpperCase());
		System.out.println(s3.charAt(1));
		
		
		//String buffer 
		StringBuffer sb=new StringBuffer("Welcome to java");
		sb.append("Enjoy the llearning");
		System.out.println(sb);
		//insert 
		sb.insert(0, 'w');
		System.out.println(sb);
		sb.delete(0, 1);
		System.out.println(sb);
		
		//string builder
		StringBuilder sb1= new StringBuilder("happy");
		sb1.append("Learning");
		System.out.println(sb1);
		System.out.println(sb1.delete(0, 1));
		System.out.println(sb1.insert(0, "H"));
		System.out.println(sb1.reverse());
		
		//convertion can happen in string builder and string buffer 
		//convertion of string to string buffer
		String str= "hello";
		StringBuffer sb3= new StringBuffer(str);
//		sb3.reverse();
//		sb3.reverse();
		System.out.println(sb3);
		//convertion to string to string builder
		StringBuilder sb4 = new StringBuilder(str);
		sb4.append("-World");
		System.out.println(sb4);
	}

}
