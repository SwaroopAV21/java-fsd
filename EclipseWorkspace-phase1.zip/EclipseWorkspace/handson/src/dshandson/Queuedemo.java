package dshandson;

//import java.util.Queue;
//import java.util.Arrays;
//import java.util.LinkedList;

public class Queuedemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//this is the inbuild method to add or remove its seems easy but to understand we can use the 2nd method enqueue
//		Queue<String> q=new LinkedList<>();
//		q.add("first");
//		q.add("Second");
//		q.add("third");
//		System.out.println("This is the Queue:"+q);
//		System.out.println("Head element:"+q.peek());
//		q.remove("third");
//		System.out.println("This is the Queue:"+q);
//		System.out.println("Head element:"+q.peek());
//		q.remove();
//		System.out.println("This is the Queue:"+q);
//		System.out.println("Head element:"+q.peek());
		
		Myq q=new Myq();
		q.enqeue(10);
		q.enqeue(20);
		q.enqeue(30);
		q.display();
		q.dequeue();
		q.display();

	}

}

class Myq{
	int SIZE=5;
	int a[]=new int[SIZE];
	int front,rear;
	
	Myq() {
		front=-1;
		rear=-1;
	}
	//helper
	boolean isEmpty() {
		if(front==-1) return true;
		return false;
	}
	boolean isFull() {
		if(front==0 && rear ==SIZE -1) {
			return true;
		}
		return false;
	}
	//operations
	void enqeue(int data) {
		if(isFull()) {
			System.out.println("enq");
		}
		else {
			if(front==-1) front=0;
			rear++;
			a[rear]=data;
			System.out.println("Inserted:"+data);
		}
	}
	//remove operation
	int dequeue() {
		if(isEmpty()) {
			System.out.println("Q is mt");
			return -1;
		}
		else {
			//in q we will del the front element as in FIFO
			//it has some elements return the front element
			int dequeueval = a[front];
			front++;
			//check if the queue is mt
			if(front>=rear) {//if front has gone past rear then we refresh the q to -1 as mt
				front=-1;
				rear=-1;
			}
			return dequeueval;
		}
	}
	void display() {

		int i;
		if (isEmpty()) {
			System.out.println("Empty Queue");
		} else {

			System.out.println("Items -> ");
			for (i = front; i <= rear; i++)
				System.out.print(a[i] + "  ");
		}
	}
}

