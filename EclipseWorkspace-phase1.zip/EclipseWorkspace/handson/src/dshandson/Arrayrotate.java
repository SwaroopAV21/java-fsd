package dshandson;

class rotat{
//i am creating the array rotate method , here k is the position of the rotates
public void rot(int[] a , int k) {
	if(k>a.length) {
		k=k%a.length;
//		System.out.println(k);
	}
	//creating a new array
	int[] res = new int[a.length];
	//for loop for entering the rotated  array first to the res array
	for(int i=0;i<k;i++) {
		res[i]=a[a.length-k+i];
//		System.out.println(res[i]+"this is the array in which we are wfirst appending the rotated arrays\n");
	}
	//now the res array would contain the number of rotated array only , ie if k=2 the last 2 elements will only the appended in this array res
	//now to add the remaining elements
	int j=0;//here i will go from the kth element because it will filled till k
	for(int i=k;i<a.length;i++) {
		res[i]=a[j];
		//here in the main array there would be the remaing array will are not rotated so i will append it to the rotated array res
		j++;
//		System.out.println(res[i]+"this is array where no rotated elements are stored\n");
	}
	System.arraycopy(res, 0, a, 0, a.length);
}
}

public class Arrayrotate {
		
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] a= {10,20,30,60,90,40,500,600,400,505};
		rotat rt= new rotat();
		rt.rot(a,12);
		for(int i:a) {
		System.out.println("-"+i+"-");
		}
	}
}
