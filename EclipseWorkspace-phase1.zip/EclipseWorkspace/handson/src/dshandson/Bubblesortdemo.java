package dshandson;

public class Bubblesortdemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a[]= {50,40,30,20,10};
		bubble(a);
	     for(int i=0;i<a.length;i++){

	         System.out.println(a[i]);
	         }
	     }

	private static void bubble(int[] a) {
		// TODO Auto-generated method stub
		int len = a.length;
        int temp = 0;
        for(int i=0;i<len;i++){
            for (int j=1;j<(len);j++){
                if(a[j-1]>a[j]){
                temp = a[j-1];
                a[j-1]= a[j];
                a[j]= temp;	
	}
}
}
}
}