package dshandson;

public class Doubleclldemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Doublell d=new Doublell();
		d.insertf(2);
		d.insertf(3);
		d.insertf(1);
		d.display();
		d.insertl(5);
		d.display();
		d.insertf(0);
		d.display();

	}

}
class Doublell{
	
	Node head;
	class Node{
		int data;
		Node next;
		Node prev;//dll contains prev
		Node(int d){
			this.data=d;
		}
	}
	//operations
	public void insertf(int data) {
		Node nnode= new Node(data);
		
		
		if(this.head==null) {
			this.head=nnode;
		}
		//case 2 if the head is not null
		else {
			nnode.next=this.head;
			this.head.prev=nnode;
			this.head=nnode;
		}
	}
		public void insertl(int data) {
			Node nnode= new Node(data);
			if(this.head==null) this.head=nnode;
			else {
				Node cur=this.head;
				while(cur.next!=null) cur=cur.next;
				cur.next=nnode;
				nnode.prev=cur;
			}
		}
		
	public void display() {
		Node cur=this.head;
		while(cur!=null) {
			System.out.println(cur.data+"->");
			cur=cur.next;
		}
		System.out.println();
	}
}

