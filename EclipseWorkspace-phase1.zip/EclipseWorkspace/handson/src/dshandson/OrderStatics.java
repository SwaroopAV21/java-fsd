package dshandson;

public class OrderStatics {

	public static void main(String[] args) {
		
		int[] a= {2,6,15,12,7,64,41};
		int k=2;
		findkthsmallest(a,k);
	}

	private static void findkthsmallest(int[] a, int k) {
		// TODO Auto-generated method stub
		if(a ==null|| a.length<k) {
			throw new IllegalArgumentException("Invalid INput");
		}
		int res=quickselect(a,0,a.length-1,k-1);
		System.out.println(k+"th smalles element:"+res);
		
	}

	private static int quickselect(int[] a, int left, int right, int k) {
		// TODO Auto-generated method stub
		if(left==right) return a[left];
		
		int pivotindex = partition(a,left,right);
		
		if(k==pivotindex) return a[k];
		
		if(k<pivotindex) return quickselect(a,left,pivotindex-1,k);
		else quickselect(a,pivotindex+1,right,k);
		
		return 0;
	}

	private static int partition(int[] a, int left, int right) {
		// TODO Auto-generated method stub
		int pivotval=a[right];
		int pivotindex=0;
		
		for(int i=0;i<right;i++) {
			if(a[i]<pivotval) {
				swap(a,i,pivotindex);
				pivotindex++;
			}
		}
		swap(a,pivotindex,right);
		
		return pivotindex;
	}

	private static void swap(int[] a, int i, int pivotindex) {
		// TODO Auto-generated method stub
		int temp=a[i];
		a[i]=a[pivotindex];
		a[pivotindex]=temp;
		
	}
	
}
