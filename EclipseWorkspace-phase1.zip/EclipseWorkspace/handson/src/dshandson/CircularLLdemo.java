package dshandson;

public class CircularLLdemo {
//in this the tail or the last node points back to the head
	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		create a cc ll

		Circularll c= new Circularll();
		c.sortedinsert(5);
		c.display();
		c.sortedinsert(2);
		c.display();
		c.sortedinsert(3);
		c.display();
		
	}

}

class Circularll {
	Node head;
	class Node {
		int data;
		Node next;
		Node(int d){
			this.data=d;
		}
	}
	
	//operations 
	
	void sortedinsert(int data) {
		Node nnode= new Node(data);
		//if cll is mt
		if(this.head==null) {
			this.head=nnode;
			nnode.next=nnode;//we are pointing the new element to itself
		}
		//where the list is not mt
		//and data to insert is less that head node
		Node curr = this.head;
		if(nnode.data <curr.data) {
			while(curr.next!=this.head) 
				curr=curr.next;
			curr.next=nnode;
			nnode.next=this.head;
			this.head = nnode;			
		}
		//if cll is not mt and data is > than the head
		if(nnode.data >= curr.data ) {
			while(curr.next!=this.head && curr.next.data < nnode.data) curr=curr.next;
			nnode.next=curr.next;
			curr.next= nnode;
		}
}
	void display() {
		Node cur=this.head;
		do
		{
			System.out.println(cur.data+"->");
			cur =cur.next;
		}while(cur!=this.head);
		System.out.println();
	}
}
