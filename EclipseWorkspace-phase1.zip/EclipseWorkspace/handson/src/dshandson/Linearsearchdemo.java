package dshandson;

public class Linearsearchdemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[] = {10,20,30,50,60,40};
		int pos=linear(a,90);
		if(pos!=-1) {
			System.out.println("found");
		}
		else System.out.println("Not found");
	}

	private static int linear(int[] a, int k) {
		// TODO Auto-generated method stub
		for(int i =0;i<a.length;i++) {
			if(a[i]==k) return i;			
		}
		return -1;
		
	}

}
