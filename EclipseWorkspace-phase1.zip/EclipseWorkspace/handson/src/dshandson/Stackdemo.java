package dshandson;

public class Stackdemo {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Mystack ms=new Mystack();
		ms.push(2);
		ms.push(3);
		ms.pop();

	}

}
class Mystack {
	static final int MAX=1000;
	int top;
	int [] a = new int[MAX];
	
	//helper functions
	boolean isEmpty() {
		return(top<0);
	}
	Mystack(){
		top=-1;//this means the stack is empty
	}
	//typical operations of a stack push and pop
	boolean push (int data){
		if(top>MAX-1) {
			System.out.println("Stackoverflow:");
			return false;
		}
		else {
			a[++top]=data;//first the top will be increamented so top will be 0 that means stack is  not full
			System.out.println("Pushed");
			return true;
		}
		
	}
	int pop() {
		if(top<0) {
			System.out.println("Stack Underflow");
			return -1;
		}
		else {
			int x =a[top--];
			System.out.println("Poped");
			return x;
		}
	}
	
	
	
	
	
	
}