package dshandson;

public class MyLinkedListdemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Mylinkedlist ll= new Mylinkedlist();
		ll.insert(8);
		ll.insert(9);
		ll.insert(10);
		ll.insert(6);
		ll.display();
		
		ll.delete(8);
		ll.display();

	}

}
//this is creating node , so every LL has a head and tail which will point to null or another data
class Mylinkedlist{
	Node head;
	class Node{
		int data;
		Node next;
		public Node(int d){
			this.data=d;
		}
	}
	
	Mylinkedlist(){
		
}
	//some operations ~insert so before inserting a data we hv to make that element as a node
	public void insert(int data) {
		Node nnode= new Node(data);
		
		//case 1 if head or LL is null or mpty
		if(this.head==null) this.head=nnode;
		//if LL has elements present , so we have to add the element at the last or to the tail , so we use a temp node
		//that temp node will travel till the last node and then we will point the last next with the new node ie like temp.next=newnode and the tail of the new node wil point to null like this newnode.next= null;
		//we need no to set the last next to null because in java it will point to null itself
		else {
			Node tempnode= this.head;
			//now we travel inside the list
			while(tempnode.next!=null) tempnode=tempnode.next;//this is incrementing the node
			//after this loop the tempnode will be at the last of the list
			tempnode.next = nnode;//now the tempnode will point to the new node 
		}
	}
	
	public void display() {
		//here also we travel same
		//here this is a demo , but we have to check of the head is null or not if null then we print  a msg of mt list
		Node node=this.head;
		while(node!=null) {
			System.out.println(node.data+"-->");
			node= node.next;
		}
		System.out.println();
	}
	//some operation ~delete
	public void delete(int dat) { //data is the data to be deleted
		//here we use prev and the temp node which points to head
		//we shud check data for every travel if its matches the we delete 
		//first we check if the head the data we need to del
		if(this.head.data==dat) {
			this.head = this.head.next;
			System.out.println("Found-"+dat);//we will point the head to its next 
		}
		//if key inside the list
		Node temp = this.head ;
		Node prev= null;
		while(temp.next!=null && temp.data!=dat) {
			prev = temp;//we are giving the node to prev and point temp node next to its next
			temp=temp.next;
	}
		//after completing the while loop we hv either the end of the list
		//if we are here then the key was not found or the key was not found
		if(temp!=null && temp.data==dat) { //if the key was not found and reached to end we see if the end node is the key or not
			prev.next=temp.next;
			System.out.println("Found-"+dat);
		}
		else if(temp!=null && temp.data==dat) System.out.println("Not found");
	}
}
	
