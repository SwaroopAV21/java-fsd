package dshandson;

public class Binarysearchdemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]= {10,20,30,3060,80};
		int b= binary(a,0,a.length-1,100);
		if(b!=-1) System.out.println("FOund");
		else System.out.println("!FOund");

	}

	public static int binary(int[] a, int start, int end, int k) {
		// TODO Auto-generated method stub
		int mid=(start+end)/2;
		while(start<=end) {
			if(k==a[mid]) return mid;
			else if(k<a[mid]) {
				end=mid-1;//so if k is less that mid then the key wil be in the first half 
			}//so no the end will be before mid
			else {
				start=mid+1;
			}
			mid=(start+end)/2;
		}
		//if we are here or the value is not found the we return -1 
		return -1;
	}

}
