package dshandson;

public class Quicksortdemo {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		qsort q=new qsort();
		int a[]= {40 ,20,30,10,50};
		q.printArray(a);
		q.sort(a,0,a.length-1);
		q.printArray(a);
	}
}

class qsort {
	public void sort(int[] a,int s,int e) {
		// TODO Auto-generated method stub
		if(s<e) {
			int part=partition(a,s,e);
			sort(a,s,part-1);
			sort(a,part+1,e);}}
	
	private int partition(int[] a, int s, int e) {
		// TODO Auto-generated method stub
		int index = a[e]; int i=(s-1);
		for(int j=s;j<e;j++) { 
			if(a[j]<=index) {
				i++;
				int temp=a[i]; a[i]=a[j];a[j]=temp;}}
		int temp =a[i+1];a[i+1]=a[e];a[e]=temp;
		return i+1;
	}
	public void printArray(int[] arr) {
		// TODO Auto-generated method stub
		int n = arr.length;
        for (int i=0; i<n; ++i) System.out.print(arr[i]+" ");
        System.out.println();		
	}
}
