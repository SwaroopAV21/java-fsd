package dshandson;

public class Matrixdemo {
	//matrix produ of mxn * nxq=mxq
	//for multiplication we m and q must be equal to be multiplied

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int r1=2,c1=3;
		int r2=3,c2=2;
		int[][] a1= {{1,2,3},{4,5,6}};
		int[][] a2= {{7,8},{9,10},{11,12}};
		//this is product mxq matrix 
		int[][] product=mulmatrix(a1,a2,r1,c1,c2);
		display(product);

	}

	private static int[][] mulmatrix(int[][] a1, int[][] a2, int r1, int c1, int c2) {
		// TODO Auto-generated method stub
		int [][] product = new int[r1][c2];//this is the mxq matrix
		for(int i=0;i<r1;i++) {
			for(int j=0;j<c2;j++) {
				for(int k=0;k<c1;k++) {
					product[i][j]+=a1[i][k]*a2[k][j];
				}
			}
		}
		return product;
	}

	private static void display(int[][] product) {
		// TODO Auto-generated method stub
		System.out.println("Product");
		for(int[] r:product) {
//			System.out.println(r+"-");
			for(int c:r) {
				System.out.println(c+"-");
			}
			System.out.println("\n");
		}		
	}

}
