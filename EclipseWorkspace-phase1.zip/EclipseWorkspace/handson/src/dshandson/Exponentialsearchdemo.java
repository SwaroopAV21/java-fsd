package dshandson;

public class Exponentialsearchdemo {
//every search should work on sorted array
	//we will double our search like see every time we do i++ , so in thhis we will do i*2
	//we will perform binary search in this 
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//i am creating a obje because in this , if our i crosses the range then we cann the binarysearch as array,i/2,math.min(i,sizeofarray-1)
		int a[]= {10,20,30,60,80,90};
		int e=expsearch(a,a.length,10);
		if(e!=-1) System.out.println("FOund");
		else System.out.println("!Found");

	}

private static int expsearch(int[] a, int length, int k) {
	// TODO Auto-generated method stub
	//first we search if the first element is the key or not
	if(k==a[0]) return 0;
	int i=1;
	while(i<length && a[i]<k) {
		i=i*2;
	}
	return Binarysearchdemo.binary(a, i/2, Math.min(i, length-1), k);
}

}
