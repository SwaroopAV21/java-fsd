package dshandson;

public class Mergesortdemo {
//it is very usefull because it is used for large scale database.
	//partition them blindly utill we hv one element
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		merge m = new merge();
		int a[]= {40,50,60,10,20};
		m.printArray(a);
		m.mergesort(a,0,a.length-1);
		m.printArray(a);

	}

}
class merge {
	
	public void mergesort(int[] a,int s,int e) {
		// TODO Auto-generated method stub
		if(s<e) {
			int mid=(s+e)/2;
			mergesort(a,s,mid);
			mergesort(a,mid+1,e);
			//in this we will sort
			mergesort(a,s,mid,e);		
		}
	}
	
    public void mergesort(int[] a, int s, int m,int e) {
		// TODO Auto-generated method stub
    	int n1=m-s+1;int n2=e-m;
    	int a1[]=new int[n1];int a2[]= new int[n2];
    	
    	for(int i=0;i<n1;i++) a1[i]=a[s+i];
    	for(int j=0;j<n2;j++) a2[j]=a[m+1+j];
    	int i=0,j=0,k=s;
    	while(i<n1 && j<n2) {
    		if(a1[i]<=a2[j]) {a[k]=a1[i]; i++ ;}
    		else {a[k]=a2[j]; j++;}
    		k++;
    	}
    	while(i<n1) { a[k]=a1[i];i++;k++;}
    	while(j<n2) { a[k]=a2[j];j++;k++;}	
	}

	void printArray(int arr[]){
       int n = arr.length;
       for (int i=0; i<n; ++i)
           System.out.print(arr[i] + " ");
       System.out.println();
   }
	
}
