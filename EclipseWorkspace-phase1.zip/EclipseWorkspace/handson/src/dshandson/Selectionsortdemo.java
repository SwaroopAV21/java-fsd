package dshandson;

import java.util.Arrays;

public class Selectionsortdemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]= {60,90,80,40,70};
		System.out.println("Given array:"+Arrays.toString(a));
		selectionsort(a);
		System.out.println("Sorted array:"+Arrays.toString(a));

	}

	private static void selectionsort(int[] a) {
		// TODO Auto-generated method stub
		
		for(int i=0;i<a.length;i++) {
			int mid=i;
			for(int j=i+1;j<a.length;j++) {
				if(a[j] < a[mid]) {
					mid=j;
				}
			}
			
			//swap if i and min index ie mid are at diff pos
			if (i != mid) {
				int temp = a[i];
				a[i] = a[mid];
				a[mid] = temp;
			}
		}
		
	}

}
