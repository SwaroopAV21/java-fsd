package dshandson;

public class Rangequeriesdemo {
	//k is number of columns
static int k=16;
static int n=10000;
static long[][] t=new long[n][k+1];
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]= {3,7,2,5,8,9};
		int n= a.length;
		sparse(a,n);
		System.out.println(q(0,5));
		

	}
	//1<<1 2 power 1 =2
	//1<<2 2 power 2 =4
	//1<<3 2 power 3=8
	//here 1 represents 2as binary , as (2)pow1

	 static long q(int l, int r) {
		// TODO Auto-generated method stub
		 long ans=0;
		 for(int j=k;j>0;j--) {
			 if(l+(1<<j)-1<=r) {
				 ans=ans+t[l][j];
				 System.out.println(ans+"+");

				 l+=1<<j;
			 }
		 }
		 return ans;
	}

	private static void sparse(int[] a, int n) {
		// TODO Auto-generated method stub
		for(int i=0;i<n;i++) t[i][0]=a[i];
		for(int j=1;j<=k;j++) {
			for(int i=0;i<=n-(1<<j);j++) {
				t[i][j]=t[i][j-1]+t[i+(1<<(j-1))][j-1];
				System.out.println(t[i][j]+"-"+(1<<(j-1))+"--");

			}
		}
		
	}

}
/*
 * class sparsetable{
 * int[][] sparsetable;
 * public sparsetable(int[] arr){
 * int n=arr.length;
 * int noofcol=(int)(Math.log(n)/math.log(2))+1;
 * sparsetable = new int[n][]noofcol];
 *intitialize the sparse table with the values ffrom the input array 
 *
 *for(int i=0;i<noofcol;i++) sparsetable[i][0];
 * its the same for loop used in spare//
 *}
 *}
 *
 */
