package movie;

import java.util.*;

class Camera {
    private String brand;
    private String model;
    private double perDayRentalAmount;
    private boolean available;

    public Camera(String brand, String model, double perDayRentalAmount) {
        this.brand = brand;
        this.model = model;
        this.perDayRentalAmount = perDayRentalAmount;
        this.available = true;
    }

    // Getters and setters

    public String getBrand() {
        return brand;
    }

    public String getModel() {
        return model;
    }

    public double getPerDayRentalAmount() {
        return perDayRentalAmount;
    }

    public boolean isAvailable() {
        return available;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }
}

//class InsufficientBalanceException extends Exception {
//	public InsufficientBalanceException(String message) {
//        super(message);
//    }
//}

class CameraRentalApplication {
     List<Camera> cameraList;
    private double walletBalance;

    public CameraRentalApplication() {
        cameraList = new ArrayList<>();
        walletBalance = 0.0;
    }

    public void addCamera(String brand, String model, double perDayRentalAmount) {
        Camera camera = new Camera(brand, model, perDayRentalAmount);
        cameraList.add(camera);
    }

    public void displayCameraList() {
        if (cameraList.isEmpty()) {
            System.out.println("No Data Present at This Moment.");
        } else {
            System.out.println("Available Cameras:");
            for (Camera camera : cameraList) {
                if (camera.isAvailable()) {
                    System.out.println("Brand: " + camera.getBrand());
                    System.out.println("Model: " + camera.getModel());
                    System.out.println("Per-day Rental Amount: $" + camera.getPerDayRentalAmount());
                    System.out.println("--------------------");
                }
            }
        }
    }

    public void rentCamera(int cameraIndex, int rentalDuration) throws Exception {
        Camera camera = cameraList.get(cameraIndex);

        if (!camera.isAvailable()) {
            System.out.println("Camera is not available for rent.");
            return;
        }

        double rentalCost = camera.getPerDayRentalAmount() * rentalDuration;

        if (walletBalance < rentalCost) {
            throw new Exception("Insufficient balance in the wallet.");
        }

        walletBalance -= rentalCost;
        camera.setAvailable(false);

        System.out.println("Camera rented successfully.");
    }

    public void displayWalletBalance() {
        System.out.println("Wallet Balance: $" + walletBalance);
    }

    public void depositToWallet(double amount) {
        if (amount <= 0) {
            System.out.println("Invalid deposit amount.");
            return;
        }

        walletBalance += amount;
        System.out.println("Deposit successful.");
    }

    public void sortCameraList(Comparator<Camera> comparator) {
        Collections.sort(cameraList, comparator);
    }
}

