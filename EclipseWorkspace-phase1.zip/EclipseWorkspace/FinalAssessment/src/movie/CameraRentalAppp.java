package movie;

import java.util.*;

public class CameraRentalAppp {
    public static void main(String[] args) {
        CameraRentalApplication app = new CameraRentalApplication();

        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            displayWelcomeScreen();
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    handleAddCamera(app, scanner);
                    break;
                case 2:
                    handleRentCamera(app, scanner);
                    break;
                case 3:
                    handleWalletManagement(app, scanner);
                    break;
                case 4:
                    System.out.println("Exiting the application. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 4);
    }

    private static void displayWelcomeScreen() {
        System.out.println("Camera Rental Application");
        System.out.println("-------------------------");
        System.out.println("1. Add a camera");
        System.out.println("2. Rent a camera");
        System.out.println("3. Wallet Management");
        System.out.println("4. Exit");
        System.out.print("Enter your choice: ");
    }

    private static void handleAddCamera(CameraRentalApplication app, Scanner scanner) {
        System.out.println("Add a Camera");
        System.out.println("------------");

        scanner.nextLine(); // Consume newline character

        System.out.print("Enter the brand: ");
        String brand = scanner.nextLine();

        System.out.print("Enter the model: ");
        String model = scanner.nextLine();

        System.out.print("Enter the per-day rental amount: ");
        double rentalAmount = scanner.nextDouble();

        app.addCamera(brand, model, rentalAmount);
        System.out.println("Camera added successfully.");
    }

    private static void handleRentCamera(CameraRentalApplication app, Scanner scanner) {
        System.out.println("Rent a Camera");
        System.out.println("-------------");

        app.displayCameraList();

        if (app.cameraList.isEmpty()) {
            System.out.println("No cameras available for rent.");
            return;
        }

        System.out.print("Enter the index of the camera to rent: ");
        int cameraIndex = scanner.nextInt();

        System.out.print("Enter the rental duration (in days): ");
        int rentalDuration = scanner.nextInt();

        try {
            app.rentCamera(cameraIndex, rentalDuration);
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void handleWalletManagement(CameraRentalApplication app, Scanner scanner) {
        System.out.println("Wallet Management");
        System.out.println("-----------------");

        System.out.println("1. View Wallet Balance");
        System.out.println("2. Deposit Funds");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();

        switch (choice) {
            case 1:
                app.displayWalletBalance();
                break;
            case 2:
                System.out.print("Enter the amount to deposit: ");
                double amount = scanner.nextDouble();
                app.depositToWallet(amount);
                break;
            default:
                System.out.println("Invalid choice. Returning to the main menu.");
        }
    }
}
