package phase1;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;


class Camera {
    private String brand;
    private String model;
    private double perDayRentalAmount;
    private boolean available;

    public Camera( String brand, String model, double perDayRentalAmount) {
        this.brand = brand;
        this.model = model;
        this.perDayRentalAmount = perDayRentalAmount;
        this.available = true;
    }

    // Getters and setters

    public String getBrand() {
        return brand;
    }

    public String getModel() {
        return model;
    }

    public double getPerDayRentalAmount() {
        return perDayRentalAmount;
    }

    public boolean isAvailable() {
        return available;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }
}

//custom exception
class InsufficientBalanceException extends Exception {
	private static final long serialVersionUID = 1L;
	public InsufficientBalanceException(String message) {
        super(message);
    }
}
class InvalidIndex  extends Exception {
	private static final long serialVersionUID = 1L;
	public InvalidIndex(String message) {
		super(message);
	}
}


//this is class  we used many functions such as  append a new camera to the list and rent a camera and add or deduct money from the wallet.
class CameraRentalApplication {
     List<Camera> cameraList;
    private double walletBalance;

    public CameraRentalApplication() {
        cameraList = new ArrayList<>();
        walletBalance = 0.0;
    }

    public void addCamera(String brand, String model, double perDayRentalAmount) {
        Camera camera = new Camera(brand, model, perDayRentalAmount);
        cameraList.add(camera);
    }
    

    public void deleteCamera(int index)  throws InvalidIndex{
    	if(index<=0) throw new InvalidIndex("Invalid Index");
    	if(cameraList.isEmpty()) System.out.println("There are no cameras to remove, You can add a camera");
    	cameraList.remove(index);
    }
    //displaying the camera's present
    public void displayCameraList() {
        if (cameraList.isEmpty()) {
            System.out.println("No Data Present at This Moment.");
        } else {
            System.out.println("Available Cameras:");
            for (Camera camera : cameraList) {
                if (camera.isAvailable()) {
                    System.out.println("Brand: " + camera.getBrand());
                    System.out.println("Model: " + camera.getModel());
                    System.out.println("Per-day Rental Amount: $" + camera.getPerDayRentalAmount());
                    System.out.println("\n--------+-+---------");
                }
            }
        }
    }

    public void rentCamera(int cameraIndex, int rentalDuration) throws InsufficientBalanceException {
        Camera camera = cameraList.get(cameraIndex);

        if (!camera.isAvailable()) {
            System.out.println("Camera is not available for rent.");
            return;
        }

        double rentalCost = camera.getPerDayRentalAmount() * rentalDuration;

        if (walletBalance < rentalCost) {
            throw new InsufficientBalanceException("Insufficient balance in the wallet.");
        }

        walletBalance -= rentalCost;
        camera.setAvailable(false);

        System.out.println("Camera rented successfully.");
    }

    public void displayWalletBalance() {
        System.out.println("Wallet Balance: $" + walletBalance);
    }

    public void depositToWallet(double amount) {
        if (amount <= 0) {
            System.out.println("Invalid deposit amount.");
            return;
        }

        walletBalance += amount;
        System.out.println("Deposit successful.");
    }
    //sorting
    public void sortCameraList(Comparator<Camera> comparator) {
        Collections.sort(cameraList, comparator);
    }
    //searching
	public void search(String model,String brand) {
    	if (cameraList.isEmpty()) {
            System.out.println("No Data Present at This Moment.");
        } else {
    	for(Camera i :cameraList) {
    		if((i.getBrand().equalsIgnoreCase(brand)) && i.getModel().equalsIgnoreCase(model)) {
                System.out.println("Camera your were looking :");
    			System.out.println("Brand: " + i.getBrand());
                System.out.println("Model: " + i.getModel());
                System.out.println("Per-day Rental Amount: $" + i.getPerDayRentalAmount());
                System.out.println("\n--------+-+---------");
    		}
    	}
    }
    }
}