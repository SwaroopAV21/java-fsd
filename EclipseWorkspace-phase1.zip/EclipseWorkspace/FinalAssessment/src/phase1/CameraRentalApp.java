package phase1;


import java.util.*;

public class CameraRentalApp {
    public static void main(String[] args) {
    	//CameraRentalApplication class is in camera.java file we have created a instance to call various functions
        CameraRentalApplication app = new CameraRentalApplication();

        //User.java files consists of setting username and password method
        User u=new User();
        Scanner scanner = new Scanner(System.in);
        int choice;
        
        System.out.println("+---+---+----+----+----+---+----+----+");
        System.out.println("|Welcome To Camera Rental Application|");
        System.out.println("+---+---+---+---+---+---+---+----+---+");
        System.out.println("Please Login to Continue");
        System.out.println("+-------+");
        System.out.print("Username: ");
        System.out.println("\n+-------+");
        String admin=scanner.next();
        u.setName(admin);
        System.out.println("+-------+");
        System.out.print("Password: ");
        System.out.println("\n+-------+");
        String password=scanner.next();
        u.setPassword(password);
     
//        System.out.println(u.toString());
//			to check whether the enter admin name and password are returned.        
       
        //checking whether the entered uname and pwd is crt or not
        if(admin.equalsIgnoreCase(u.getName()) && password.equals(u.getPassword())  ){
        do {
        	//displaying the menu screen on every choice
            displayWelcomeScreen();
            choice = scanner.nextInt();
            switch (choice) {
                case 1:
                    handleAddCamera(app, scanner);
                    break;
                case 2:
                    handleRentCamera(app, scanner);
                    break;
                case 3:
                    handleWalletManagement(app, scanner);
                    break;
                case 4:
                	app.displayCameraList();
                	break;
                case 5:
                	System.out.println("Enter the camera brand:");
                	String brand=scanner.next();
                	System.out.println("Enter the camera model");
                	String model=scanner.next();
                	app.search(brand, model);
                	break;
                case 6:
                    System.out.println("Exiting the application. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 6);
    }
        else {
            System.out.print("You have entered the Wrong password or username");
        }
    
}
    

    private static void displayWelcomeScreen() {
        System.out.println("---+---+----+----+----+---+");
        System.out.println("Camera Rental Application Main Menu");
        System.out.println("---+---+---+---+---+---+---+");
        System.out.println("1. Add a camera");
        System.out.println("2. Rent a camera");
        System.out.println("3. Wallet Management");
        System.out.println("4. Display Camera List");
        System.out.println("5. Want to search any camera?");
        System.out.println("6. Exit");
        System.out.print("Enter your choice: ");
    }

    //method to add camera , inside which called another method from camera.java
    private static void handleAddCamera(CameraRentalApplication app, Scanner scanner) {
        
    	int choice;
    	
    	do {
            System.out.println("---+---+---+---+---+---+---+");
            System.out.println("1. Add a camera");
            System.out.println("2. Remove");
            System.out.println("3. My cameras ");
            System.out.println("4. Back to main menu");
            System.out.print("Enter your choice: ");
        	choice=scanner.nextInt();
            System.out.println("\n---+---+---+---+---+---+---+");

        	switch(choice) {
        	case 1:
            	System.out.println("Add a Camera");
                System.out.println("------------");

                scanner.nextLine(); // Consume newline character

                System.out.print("Enter the brand: ");
                String brand = scanner.nextLine();

                System.out.print("Enter the model: ");
                String model = scanner.nextLine();

                System.out.print("Enter the per-day rental amount: ");
                double rentalAmount = scanner.nextDouble();

                app.addCamera(brand, model, rentalAmount);
                System.out.println("Camera added successfully.");
                break;
        	case 2:
        		System.out.println("Enter the index Number to Remove a camera:");
        		int index=scanner.nextInt();
        		try {
					app.deleteCamera(index-1);
	        		System.out.println("Camera at "+index+"Removed.");
				} catch (InvalidIndex e) {
					System.out.println(e.getMessage());}

        		break;
        	case 3:
        		app.displayCameraList();
        		break;
        	default:
                System.out.println("Enter a Valid choice:");
        	}
    	}while(choice!=4);

    }

    //to rent a camera and to check if the balance is available or not
    private static void handleRentCamera(CameraRentalApplication app, Scanner scanner) {
        System.out.println("Rent a Camera");
        System.out.println("-------------");

        app.displayCameraList();

        if (app.cameraList.isEmpty()) {
            System.out.println("No cameras available for rent.");
            return;
        }

        System.out.print("Enter the index of the camera to rent: ");
        int cameraIndex = scanner.nextInt();

        System.out.print("Enter the rental duration (in days): ");
        int rentalDuration = scanner.nextInt();

        try {
            app.rentCamera(cameraIndex-1, rentalDuration);
        } catch (InsufficientBalanceException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    
    //wallet prices to show the amount left and also to add the amount
    private static void handleWalletManagement(CameraRentalApplication app, Scanner scanner) {
        System.out.println("Wallet Management");
        System.out.println("-----------------");

        System.out.println("1. View Wallet Balance");
        System.out.println("2. Deposit Funds");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();

        switch (choice) {
            case 1:
                app.displayWalletBalance();
                break;
            case 2:
                System.out.print("Enter the amount to deposit: ");
                double amount = scanner.nextDouble();
                app.depositToWallet(amount);
                break;
            default:
                System.out.println("Invalid choice. Returning to the main menu.");
        }
    }
}
