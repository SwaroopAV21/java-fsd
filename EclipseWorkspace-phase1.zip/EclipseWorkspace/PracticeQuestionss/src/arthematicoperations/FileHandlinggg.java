package arthematicoperations;
import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
public class FileHandlinggg {

	public static void main(String[] args)  throws Exception{
		// I am creating a file  and writing with appending using FileOutputstream , I am reading file using FileReader to read and display ;
		createfile();
		readfile();
	}


	private static void readfile() throws Exception {
		try {
			String a=null;
			FileReader fi = new FileReader("c://temp//testFile4.txt");
			//Using buffer reader to display the files in the file
			BufferedReader rf= new BufferedReader(fi);
			System.out.println("Strings enter are:");
			while((a=rf.readLine())!=null) {
				System.out.println(a);
			}
			fi.close();
		}
		catch(IOException e) {
			System.out.println(e);
		}
		
	}

	private static void createfile() throws Exception {
		try {
		String entrydata="Hi i am entering this data using FIleOutputStream";
		String entrydata1="\nHello This is entered too";
		FileOutputStream fo= new FileOutputStream("c://temp//testFile4.txt");
		fo.write(entrydata.getBytes());
		fo.write(entrydata1.getBytes());
		System.out.println("The file is created and Written:\n");
		fo.close();
		}
		catch(IOException e) {
			System.out.println("An Error occured-"+e);
		}
	}
	

}
