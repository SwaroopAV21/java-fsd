package arthematicoperations;
import java.util.*;
 
class aoperations{
	static int add(int x,int y) {
		int result=x+y; 
		System.out.println("Addition of:"+x+"+"+y+"is:"+result);
		return result;
	}
	static int sub(int x ,int y) {
		int result=x-y;
			System.out.println("Subtraction of:"+x+"-"+y+"is:"+result);
			return result;
	}
	static int mul(int x, int y) {
		int res=x*y;
		System.out.println("Multiplication of :"+x+"x"+y+"is:"+res);
		return res;
	}
	static int div(int x, int y) {
		double res=y/x;
		System.out.println("Division of :"+y+"/"+x+"is:"+res);
		return (int)res;
	}
	
}



public class AthematicOperations {
	public static void main(String[] args) {
		final int num1=100, num2=200;
		aoperations a=new aoperations();
		a.add(num1, num2);
		a.sub(num1, num2);
		a.mul(num1, num2);
		aoperations.div(num1, num2);
		
	}

}
