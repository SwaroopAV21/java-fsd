package arthematicoperations;
import java.util.*;
import java.util.regex.*;
import java.util.Scanner;


public class EmailValidation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> ar=new ArrayList<String>();
		ar.add("Abc@gmail.com");
		ar.add("adc@gmail.com");
		ar.add("xyz@domain.com");
		ar.add("poi@domaincom");
		ar.add("xyz@gmail.com");
		ar.add("asdfc");
		ar.add("@hjk");
		
		String regex="^(.+)@(.+)$";
		Pattern p=Pattern.compile(regex);
		for(String a:ar) {
			Matcher m=p.matcher(a);
			System.out.println(a+" "+m.matches()+"\n");
		}
	}
}
