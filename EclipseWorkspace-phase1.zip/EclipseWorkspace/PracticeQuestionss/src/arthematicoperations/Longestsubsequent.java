package arthematicoperations;

import java.util.Arrays;

public class Longestsubsequent {
    public static void main(String[] args) {
        int[] arr = {3, 10, 2, 1, 20};
        int n = arr.length;
        int[] lis = new int[n];

        // Initialize LIS values for all indices
        Arrays.fill(lis, 1);

        // Compute optimized LIS values in bottom up manner
        for (int i = 1; i < n; i++) {
            for (int j = 0; j < i; j++) {
                if (arr[i] > arr[j] && lis[i] < lis[j] + 1) {
                    lis[i] = lis[j] + 1;
                }
            }
        }

        // Pick maximum of all LIS values
        int maxLis = Integer.MIN_VALUE;
        for (int i = 0; i < n; i++) {
            if (lis[i] > maxLis) {
                maxLis = lis[i];
            }
        }

        System.out.println("Length of longest increasing subsequence is: " + maxLis);
    }
}